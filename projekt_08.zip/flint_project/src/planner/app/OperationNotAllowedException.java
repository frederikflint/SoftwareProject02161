package planner.app;

public class OperationNotAllowedException extends Exception {

    /**
     * If the operation is not allowed throw OperationNotAllowedException.
     * @param errorMsg the error message
     * @author Mads Christensen
     */
    public OperationNotAllowedException(String errorMsg) {
        super(errorMsg);
    }
}
