PROGRAM:
Programmet køres ved at køre App.java.
Når programmet starter op i kommandolinjen bliver man bedt om at logge ind.
Her skal du benytte standard admin brugeren: ADMN
Når du er logget ind som admin, kan du benytte hele programmet. Den eneste forskel på ADMN og alle andre bruger
er at ADMN kan se alles registrerede syge/ferie/kursusdage

TEST:
Test køres som cucumber scenarier på hele test mappen.